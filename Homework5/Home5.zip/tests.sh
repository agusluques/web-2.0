curl http://localhost:8888/person/John%20Snow/address
echo
curl http://localhost:8888/person/Agustin%20Luques/address
echo
curl http://localhost:8888/person/DOCKER/address
echo